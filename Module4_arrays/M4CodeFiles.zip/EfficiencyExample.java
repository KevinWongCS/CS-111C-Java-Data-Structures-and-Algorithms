public class EfficiencyExample {
	
	public static void main(String[] args) {

		ArrayBag<Integer> bag = new ArrayBag<Integer>(ArrayBag.MAX_CAPACITY);
		int oldNumber = 1;
		int newNumber = 2;
		for(int i=0; i<ArrayBag.MAX_CAPACITY; i++) {
			bag.add(oldNumber);
		}
		System.out.print("Old number " + oldNumber + " appears " + bag.getFrequencyOf(oldNumber) + " times.");
		System.out.println("\tNew number " + newNumber + " appears " + bag.getFrequencyOf(newNumber) + " times.");
		
		long startTime = System.currentTimeMillis();
		//bag.replaceAllBad(oldNumber, newNumber);
		bag.replaceAllGood(oldNumber, newNumber);
		long stopTime = System.currentTimeMillis();
		System.out.println("Elapsed time = " + (stopTime - startTime));

		System.out.print("Old number " + oldNumber + " appears " + bag.getFrequencyOf(oldNumber) + " times.");
		System.out.println("\t\tNew number " + newNumber + " appears " + bag.getFrequencyOf(newNumber) + " times.");

	}
	

}