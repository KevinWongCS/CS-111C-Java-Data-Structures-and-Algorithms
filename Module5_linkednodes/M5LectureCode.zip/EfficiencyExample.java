import java.util.Random;

public class EfficiencyExample {

	public static void main(String[] args) {
		
		LList<Integer> listAInefficient = new LList<>();
		LList<Integer> listA = new LList<>();
		LList<Integer> listB = new LList<>();
		
		// create the lists
		Random generator = new Random();
		int sizeOfList = 10_000;
		for(int i=0; i<sizeOfList; i++) {
			listAInefficient.add(1, generator.nextInt(100));
			listA.add(1, generator.nextInt(100));
			listB.add(1, generator.nextInt(100));
		}
		
		System.out.println("The lists have " + listAInefficient.getLength() + " elements.\n");

		long startTimeBag = System.currentTimeMillis();
		listAInefficient.addAllAtIntervalInefficient(listB,  3);
		System.out.println("List A now has: " + listAInefficient.getLength() + " elements.");
		long stopTimeBag = System.currentTimeMillis();
		System.out.println("Elapsed time of inefficient method =  " + (stopTimeBag - startTimeBag));
		
		startTimeBag = System.currentTimeMillis();
		listA.addAllAtInterval(listB,  3);
		System.out.println("\nList A now has: " + listA.getLength() + " elements.");
		stopTimeBag = System.currentTimeMillis();
		System.out.println("Elapsed time of efficient method =  " + (stopTimeBag - startTimeBag));

	}

}
